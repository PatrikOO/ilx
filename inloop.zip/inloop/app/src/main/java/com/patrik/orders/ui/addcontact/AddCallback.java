package com.patrik.orders.ui.addcontact;

/**
 * A Callback for add contact button
 */
public interface AddCallback {

    void addClick(String name, String phone);
}
