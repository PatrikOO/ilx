package com.patrik.orders.vo;

import java.util.List;

public class Contacts {

    public List<Contact> items;


    public Contacts(List<Contact> items) {
        this.items = items;
    }
}
