package com.patrik.orders.vo;

import java.util.List;

public class Detail {

    public List<Item> items;

    public Detail(List<Item> items) {
        this.items = items;
    }
}