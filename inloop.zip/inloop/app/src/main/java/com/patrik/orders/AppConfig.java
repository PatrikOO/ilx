package com.patrik.orders;

/**
 * Global config with app data
 */
public class AppConfig {

    public static final String BASE_URL = "https://inloop-contacts.appspot.com/";

    /* delay for on click ripple */
    public static final int ON_CLICK_DELAY_MS = 200;

}


