package com.patrik.orders.vo;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
