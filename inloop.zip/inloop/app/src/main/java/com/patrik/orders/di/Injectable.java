package com.patrik.orders.di;

/**
 * Marks an activity / fragment injectable.
 */
public interface Injectable {
}
