package com.patrik.orders.vo;

public class AddResponse {

    public String id;
    public String name;
    public String phone;
}
