package com.patrik.orders.ui.main;

import android.arch.lifecycle.ViewModel;

import javax.inject.Inject;


public class MainActivityViewModel extends ViewModel {

    @SuppressWarnings("unchecked")
    @Inject
    public MainActivityViewModel() {

    }
}
